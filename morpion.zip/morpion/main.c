#include <stdio.h>
#include <stdlib.h>
#include "aide.h"
char tableau[3][3]; // Tableau representant la grille
int joueur = 1; // Variable designant le joueur actuelle ou le joueur suivant
char rond='O', croix='X', vide='_'; // Valeurs possibles des cases de la grille

void init_gril() // Fonction pour initialiser la grille
{
    int i,x; // Ces boucles permettent de parcourir toutes les lignes et colonnes de la grille
    for(i=0;i<3;i++)
    {
        for (x=0;x<3;x++)
        tableau[i][x] = vide;
    }
}
void modif() // Fonction modifiant la grille suite grace aux coordonnees entrees par le joueur
{
    int ligne, colonne;
    printf("Entrez vos coordonnees\t");
    scanf("%d %d",&ligne, &colonne);
    ligne--;
    colonne--;
    if ((ligne>=0 && ligne < 3) && (colonne>=0 && colonne<3)&& tableau[ligne][colonne]== vide)
    {
        if (joueur == 1)
        {
            printf("Joueur 1\n");
            tableau[ligne][colonne]=croix;
            affichage_grille();
            joueur = 2;
        }
        else if (joueur == 2)
        {
            printf("Joueur 2\n");
            tableau[ligne][colonne]=rond;
            affichage_grille();
            joueur = 1;
        }
    }
    else
    {
        if ((tableau[ligne][colonne]!= vide)&& (ligne >0 && ligne<3)&& (colonne >0 && ligne<3)) printf("Cette case a deja un symbole\n");
        else printf("Erreur de coordonnees\n");
    }

}
void affichage_grille() // Affiche la grille
{
    printf("%c %c %c \n",tableau[0][0], tableau[0][1], tableau[0][2]);
    printf("%c %c %c \n",tableau[1][0], tableau[1][1], tableau[1][2]);
    printf("%c %c %c \n",tableau[2][0], tableau[2][1], tableau[2][2]);
}

int main()
{
    int quitter = 1; // Cette variable va g�rer le retour au menu et l'arret du programme
    while(quitter==1)// Cette boucle enveloppe le programme
    {

    int choix,nb=0,tour=0,score1=0,score2=0,n,u;

    printf(" ************************************************************** ******************************************************\n");
    printf("*******************************************************JEU DE MORPION *************************************************\n");
    printf(" ************************************************************** ******************************************************\n");
    printf(".1- JOUER......\n");
    printf(".2- REGLES DU JEU......\n");
    printf(".0- QUITTER......\n\n");
    printf("Faites un choix dans le menu\t");
    scanf("%d",&choix);
    if (choix==1)
    {
        printf("Premier joueur :X       Deuxieme joueur :O \n");
        do
        {
            printf("Tour %d\n",tour+1);
            init_gril();
            affichage_grille();
            do
            {
                modif();
                nb+=1;
                // Gestion des cas de victoire
                if ((tableau[0][0]=='X' && tableau[0][1]=='X' && tableau[0][2]=='X')|| (tableau[0][0]=='O' && tableau[0][1]=='O' && tableau[0][2]=='O'))
                {
                    if (joueur == 2) score1 ++;
                    else if (joueur==1) score2 ++;
                    tour ++;
                    break;
                }
                if ((tableau[1][0]=='X' && tableau[1][1]=='X' && tableau[1][2]=='X')|| (tableau[1][0]=='O' && tableau[1][1]=='O' && tableau[1][2]=='O'))
                {
                    if (joueur == 2) score1 ++;
                    else if (joueur==1) score2 ++;
                    tour ++;
                    break;
                }
                if ((tableau[2][0]=='X' && tableau[2][1]=='X' && tableau[2][2]=='X')|| (tableau[2][0]=='O' && tableau[2][1]=='O' && tableau[2][2]=='O'))
                {
                    if (joueur == 2) score1 ++;
                    else if (joueur==1) score2 ++;
                    tour ++;
                    break;
                }

                if ((tableau[0][0]=='X' && tableau[1][0]=='X' && tableau[2][0]=='X')|| (tableau[0][0]=='O' && tableau[1][0]=='O' && tableau[2][0]=='O'))
                {
                    if (joueur == 2) score1 ++;
                    else if (joueur==1) score2 ++;
                    tour ++;
                    break;
                }
                if ((tableau[0][1]=='X' && tableau[1][1]=='X' && tableau[2][1]=='X')|| (tableau[0][1]=='O' && tableau[1][1]=='O' && tableau[2][1]=='O'))
                {
                    if (joueur == 2) score1 ++;
                    else if (joueur==1) score2 ++;
                    tour ++;
                    break;
                }
                if ((tableau[0][2]=='X' && tableau[1][2]=='X' && tableau[2][2]=='X')|| (tableau[0][2]=='O' && tableau[1][2]=='O' && tableau[2][2]=='O'))
                {
                    if (joueur == 2) score1 ++;
                    else if (joueur==1) score2 ++;
                    tour ++;
                    break;
                }

                if ((tableau[0][0]=='X' && tableau[1][1]=='X' && tableau[2][2]=='X')|| (tableau[0][0]=='O' && tableau[1][1]=='O' && tableau[2][2]=='O'))
                {
                    if (joueur == 2) score1 ++;
                    else if (joueur==1) score2 ++;
                    tour ++;
                    break;
                }
                if ((tableau[0][2]=='X' && tableau[1][1]=='X' && tableau[2][0]=='X')|| (tableau[0][2]=='O' && tableau[1][1]=='O' && tableau[2][0]=='O'))
                {
                    if (joueur == 2) score1 ++;
                    else if (joueur==1) score2 ++;
                    tour ++;
                    break;
                }
                // Les boucles ci-dessous parcourent la grille et detectent s'il ya au mois une case vide
                for (n=0; n<3;n++)
                {
                    for (u=0; u<3; u++)
                    {
                        if (tableau[n][u] == vide)
                        {
                            nb = 0;
                            break;
                        }
                        else
                        {
                            nb = 1;
                        }
                    }
                }
            }while(nb==0);
        }while (tour<3);
        if (tour>=3 && score1>score2) printf("Victoire du Joueur 1");
        else if (tour>=3 && score2>score1) printf("Victoire du Joueur 2");

    }
    else if (choix==2)
    {
        regles();
        printf("Entrez \"1\" pour retourner au menu\n");
        scanf("%d", &quitter);
    }
    else
    {
        quitter=0;
        printf("Arret du jeu\n");
    }

    }

    return 0;
}
