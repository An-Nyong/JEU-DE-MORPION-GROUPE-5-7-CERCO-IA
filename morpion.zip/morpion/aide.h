void regles();
