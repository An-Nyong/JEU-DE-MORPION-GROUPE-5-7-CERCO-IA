#include <stdio.h>
#include <stdlib.h>

void regles()
{
    printf(" ************************************************* **************************************************\n");
    printf(" ******************************************REGLES DU JEU **************************************************\n");
    printf("Le morpion est un jeu de reflexion se pratiquant a deux joueurs au tour par tour et dont le but est de creer le\n\
premier un alignement sur une grille (3 fois 3).\n");
    printf("_ _ X=\n");
    printf("_ X _\n");
    printf("X _ _\n");
    printf("Les joueurs inscrivent tour a tour leur symbole (X pour le premier joueur et O pour le second). Le premier qui\n\
parvient a aligner trois (3) de ses symboles horizontalement, verticalement ou en diagonale gagne un point. \n\
Le gagnant du jeu sera celui qui aura le plus de point apres trois tours de jeu.\n\
Chaque joueur devra entrer les coordonnees de sont point pour l�afficher");
    printf("Exemple, pour un premier joueur qui entrera 3 et 3, la grille se pr�sentera comme suit:\n");
    printf("_ _ _\n");
    printf("_ _ _\n");
    printf("_ _ X\n");
}
